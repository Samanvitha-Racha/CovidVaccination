package com.covid.CovidVaccination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidVaccinationApplicationTests {

	@Test
	void contextLoads() {
	}

}
