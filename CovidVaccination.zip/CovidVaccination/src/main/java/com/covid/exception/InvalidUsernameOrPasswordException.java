package com.covid.exception;

public class InvalidUsernameOrPasswordException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public InvalidUsernameOrPasswordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
